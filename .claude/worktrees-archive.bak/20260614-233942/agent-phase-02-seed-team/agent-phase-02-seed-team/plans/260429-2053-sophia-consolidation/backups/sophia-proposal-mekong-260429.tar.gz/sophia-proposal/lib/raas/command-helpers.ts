/**
 * RaaS Command Helpers
 *
 * Real execution logic for stub commands previously in command-router.ts.
 * Split out to keep command-router.ts under 200 lines.
 */

import { getD1Client } from '@/lib/db/client';
import { createVideoTask } from '@/lib/video/heygen-client';
import { generateProposal } from '@/lib/ai/claude-proposal-generator';
import { generateBattlecard } from '@/lib/ai/claude-sales-intelligence';
import type { Mission, MissionResult } from '@/types/raas';

// ============================================================================
// PROPOSAL CREATE
// ============================================================================

export async function runProposalCreate(mission: Mission): Promise<MissionResult> {
  const db = await getD1Client();
  const params = mission.params as { client_name?: string; product_name?: string; tone?: string; sections?: string[] };

  const proposal = await generateProposal({
    client_name: params.client_name ?? 'Client',
    product_name: params.product_name ?? 'Sophia AI',
    tone: params.tone,
    sections: params.sections,
  });

  // Save to proposals table — graceful degrade if table doesn't exist yet
  let proposalId: string | undefined;
  try {
    const { data } = await db
      .from<{ id: string }>('proposals')
      .insert({
        org_id: mission.org_id,
        title: `Proposal for ${params.client_name ?? 'Client'}`,
        content: proposal,
        status: 'draft',
      })
      .select('id')
      .single();
    proposalId = data?.id;
  } catch {
    // Table may not exist — continue without persisting
  }

  return {
    success: true,
    summary: `Proposal created for ${params.client_name ?? 'client'}`,
    data: { proposal_id: proposalId, proposal },
  };
}

// ============================================================================
// VIDEO CREATE
// ============================================================================

export async function runVideoCreate(mission: Mission): Promise<MissionResult> {
  const params = mission.params as { script?: string; avatar_id?: string; voice_id?: string; title?: string; video_type?: string };

  if (!params.script) {
    return { success: false, error: 'Missing params.script for video creation' };
  }

  try {
    const videoTask = await createVideoTask({
      proposalId: mission.id,
      scriptText: params.script,
      videoType: (params.video_type ?? 'full_proposal') as 'intro' | 'section' | 'full_proposal' | 'custom',
      avatarId: params.avatar_id,
      voiceId: params.voice_id,
      templateId: undefined,
    });

    return {
      success: true,
      summary: `Video submitted to HeyGen: ${videoTask.data?.video_id ?? 'pending'}`,
      data: { video_task: videoTask as unknown as Record<string, unknown> },
    };
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    return { success: false, error: `HeyGen submission failed: ${msg}` };
  }
}

// ============================================================================
// CRM SYNC
// ============================================================================

export async function runCrmSync(mission: Mission): Promise<MissionResult> {
  const db = await getD1Client();

  const { data: settings } = await db
    .from('crm_settings')
    .select('hubspot_access_token')
    .eq('org_id', mission.org_id)
    .single();

  if (!settings?.hubspot_access_token) {
    return { success: false, error: 'HubSpot not connected. Go to Settings > CRM to connect.' };
  }

  const contactsRes = await fetch('https://api.hubapi.com/crm/v3/objects/contacts?limit=100', {
    headers: { Authorization: `Bearer ${settings.hubspot_access_token}` },
  });

  if (!contactsRes.ok) {
    return { success: false, error: `HubSpot API error: ${contactsRes.status}` };
  }

  const contactsData = await contactsRes.json() as { results?: Array<{ id: string; properties?: Record<string, string> }> };
  const contacts = contactsData.results ?? [];

  let synced = 0;
  for (const c of contacts) {
    const props = c.properties ?? {};
    await db.from('contacts').upsert({
      org_id: mission.org_id,
      external_id: c.id,
      source: 'hubspot',
      email: props.email,
      first_name: props.firstname,
      last_name: props.lastname,
      company: props.company,
      updated_at: new Date().toISOString(),
    });
    synced++;
  }

  await db.from('crm_sync_status').upsert({
    org_id: mission.org_id,
    last_sync: new Date().toISOString(),
    contacts_synced: synced,
    status: 'completed',
  });

  return {
    success: true,
    summary: `CRM sync complete: ${synced} contacts synced`,
    data: { contacts_synced: synced, provider: 'hubspot' },
  };
}

// ============================================================================
// ANALYTICS EXPORT
// ============================================================================

export async function runAnalyticsExport(mission: Mission): Promise<MissionResult> {
  const db = await getD1Client();
  const params = mission.params as { days?: number; format?: string };
  const days = params.days ?? 30;
  const since = new Date(Date.now() - days * 86_400_000).toISOString();

  const [{ count: missionCount }, { data: usageLogs }] = await Promise.all([
    db
      .from('missions')
      .select('*', { count: 'exact', head: true })
      .eq('org_id', mission.org_id)
      .gte('created_at', since),
    db
      .from<{ mcu_cost: number }>('usage_logs')
      .select('mcu_cost')
      .eq('org_id', mission.org_id)
      .gte('created_at', since),
  ]);

  // Proposals table may not exist — graceful degrade
  let proposalCount = 0;
  try {
    const { count } = await db
      .from('proposals')
      .select('*', { count: 'exact', head: true })
      .eq('org_id', mission.org_id)
      .gte('created_at', since);
    proposalCount = count ?? 0;
  } catch {
    // Table not yet created
  }

  const totalMcu = (usageLogs ?? []).reduce((sum, r) => sum + (r.mcu_cost ?? 0), 0);

  return {
    success: true,
    summary: `Analytics export: ${days}d, ${proposalCount} proposals, ${missionCount ?? 0} missions, ${totalMcu} MCU used`,
    data: {
      period_days: days,
      proposals: proposalCount,
      missions: missionCount ?? 0,
      mcu_consumed: totalMcu,
      exported_at: new Date().toISOString(),
    },
  };
}

// ============================================================================
// GTM CAMPAIGN
// ============================================================================

export async function runGtmCampaign(mission: Mission): Promise<MissionResult> {
  const db = await getD1Client();
  const params = mission.params as Record<string, unknown>;

  const subCommands = [
    {
      command: 'proposal:create',
      title: `GTM Proposal: ${params.campaign_name ?? 'Campaign'}`,
      params: { client_name: params.target_client, product_name: params.product_name },
    },
    {
      command: 'content:blog',
      title: `GTM Blog: ${params.campaign_name ?? 'Campaign'}`,
      params: { topic: params.blog_topic ?? params.campaign_name },
    },
    {
      command: 'content:social',
      title: `GTM Social: ${params.campaign_name ?? 'Campaign'}`,
      params: { topic: params.campaign_name },
    },
  ];

  const createdIds: string[] = [];
  for (const sub of subCommands) {
    const { data } = await db
      .from<{ id: string }>('missions')
      .insert({
        org_id: mission.org_id,
        title: sub.title,
        command: sub.command,
        params: sub.params,
        status: 'queued',
        priority: mission.priority ?? 'normal',
        mcu_cost: 5,
        mcu_reserved: 5,
      })
      .select('id')
      .single();

    if (data) createdIds.push(data.id);
  }

  return {
    success: true,
    summary: `GTM campaign created with ${createdIds.length} sub-missions`,
    data: { sub_mission_ids: createdIds, sub_commands: subCommands.map(s => s.command) },
  };
}

// ============================================================================
// SALES BATTLECARD
// ============================================================================

export async function runSalesBattlecard(mission: Mission): Promise<MissionResult> {
  const params = mission.params as { competitor?: string; product?: string };

  if (!params.competitor) {
    return { success: false, error: 'Missing params.competitor' };
  }

  const battlecard = await generateBattlecard({
    competitor: params.competitor,
    product: params.product,
  });

  return {
    success: true,
    summary: `Battlecard generated: ${params.competitor} vs ${battlecard.our_product}`,
    data: { battlecard },
  };
}
