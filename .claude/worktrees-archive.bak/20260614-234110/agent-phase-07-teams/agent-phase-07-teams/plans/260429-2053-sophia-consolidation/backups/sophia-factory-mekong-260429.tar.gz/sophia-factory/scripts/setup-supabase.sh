#!/bin/bash
# Sophia AI Factory - Supabase Setup Script
# This script guides you through the complete Supabase setup

set -e

BLUE='\033[0;34m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${BLUE}╔════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║     SOPHIA AI FACTORY - SUPABASE SETUP WIZARD         ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════╝${NC}"
echo ""

# Step 1: Check if Supabase CLI is installed
echo -e "${YELLOW}Step 1: Checking Supabase CLI...${NC}"
if ! command -v supabase &> /dev/null; then
    echo -e "${RED}✗ Supabase CLI not found${NC}"
    echo "Install with: npm install -g supabase"
    echo "Or: brew install supabase/tap/supabase"
    exit 1
fi
echo -e "${GREEN}✓ Supabase CLI installed: $(supabase --version)${NC}"
echo ""

# Step 2: Check if logged in
echo -e "${YELLOW}Step 2: Checking Supabase login...${NC}"
if ! supabase whoami &> /dev/null; then
    echo -e "${RED}✗ Not logged in to Supabase${NC}"
    echo "Please run: supabase login"
    echo "This will open your browser for authentication."
    read -p "Press Enter after you've logged in..."
fi
echo -e "${GREEN}✓ Logged in to Supabase${NC}"
echo ""

# Step 3: Get project reference
echo -e "${YELLOW}Step 3: Supabase Project Configuration${NC}"
echo "Enter your Supabase project reference (the 'xxxxx' in https://xxxxx.supabase.co)"
echo "You can find this in Settings → API in the Supabase dashboard."
read -p "Project Reference: " PROJECT_REF

if [ -z "$PROJECT_REF" ]; then
    echo -e "${RED}✗ Project reference is required${NC}"
    exit 1
fi

echo ""
echo -e "${YELLOW}Step 4: Linking project...${NC}"
cd /Users/macbook/mekong-cli/apps/sophia-factory
supabase link --project-ref "$PROJECT_REF"

echo ""
echo -e "${GREEN}✓ Project linked successfully!${NC}"
echo ""

# Step 5: Get credentials
echo -e "${BLUE}═══════════════════════════════════════════════════════${NC}"
echo -e "${YELLOW}STEP 5: GET YOUR CREDENTIALS${NC}"
echo -e "${BLUE}═══════════════════════════════════════════════════════${NC}"
echo ""
echo "Go to: https://supabase.com/dashboard/project/$PROJECT_REF/settings/api"
echo ""
echo "You need to copy 3 values:"
echo "  1. Project URL (e.g., https://xxxxx.supabase.co)"
echo "  2. anon/public key (starts with eyJhbGc...)"
echo "  3. service_role key (keep this secret!)"
echo ""
read -p "Press Enter when you have these values ready..."

# Step 6: Create .env.local
echo ""
echo -e "${YELLOW}Step 6: Creating .env.local...${NC}"
read -p "Enter Project URL: " SUPABASE_URL
read -p "Enter anon/public key: " SUPABASE_ANON_KEY
read -p "Enter service_role key: " SUPABASE_SERVICE_KEY
read -p "Enter OpenAI API key (optional, press Enter to skip): " OPENAI_KEY

cat > .env.local << EOF
# Supabase Configuration
NEXT_PUBLIC_SUPABASE_URL=$SUPABASE_URL
NEXT_PUBLIC_SUPABASE_ANON_KEY=$SUPABASE_ANON_KEY
SUPABASE_SERVICE_ROLE_KEY=$SUPABASE_SERVICE_KEY

# OpenAI for AI Features
OPENAI_API_KEY=${OPENAI_KEY:-sk-placeholder}

# Application Settings
NEXT_PUBLIC_APP_URL=http://localhost:3000
NODE_ENV=development
EOF

echo -e "${GREEN}✓ .env.local created${NC}"
echo ""

# Step 7: Run schema
echo -e "${BLUE}═══════════════════════════════════════════════════════${NC}"
echo -e "${YELLOW}STEP 7: APPLY DATABASE SCHEMA${NC}"
echo -e "${BLUE}═══════════════════════════════════════════════════════${NC}"
echo ""
echo -e "${YELLOW}Option A: Automatic (recommended)${NC}"
echo "  Run schema and RLS policies directly via Supabase CLI"
echo ""
echo -e "${YELLOW}Option B: Manual${NC}"
echo "  Open SQL Editor in Supabase dashboard and copy/paste SQL files"
echo ""
read -p "Choose option (A/B): " OPTION

if [ "$OPTION" = "A" ] || [ "$OPTION" = "a" ]; then
    echo ""
    echo -e "${YELLOW}Applying schema.sql...${NC}"

    # Combine schema and RLS into a single SQL file
    cat database/schema.sql database/03-rls-policies.sql > /tmp/sophia-setup.sql

    # Execute via psql
    PSQL_CMD="psql $(supabase db url --project-ref $PROJECT_REF)"
    if $PSQL_CMD -f /tmp/sophia-setup.sql; then
        echo -e "${GREEN}✓ Schema applied successfully!${NC}"
    else
        echo -e "${RED}✗ Schema application failed${NC}"
        echo "Try Option B: Manual application via dashboard"
    fi

    rm /tmp/sophia-setup.sql
else
    echo ""
    echo -e "${YELLOW}Manual Application Instructions:${NC}"
    echo "1. Open https://supabase.com/dashboard/project/$PROJECT_REF/sql/new"
    echo "2. Copy content from: database/schema.sql"
    echo "3. Run it in the SQL Editor"
    echo "4. Copy content from: database/03-rls-policies.sql"
    echo "5. Run it in the SQL Editor"
    echo ""
    read -p "Press Enter after you've applied the schema..."
fi

echo ""

# Step 8: Verification
echo -e "${BLUE}═══════════════════════════════════════════════════════${NC}"
echo -e "${YELLOW}STEP 8: VERIFY CONNECTION${NC}"
echo -e "${BLUE}═══════════════════════════════════════════════════════${NC}"
echo ""

# Create a simple test script
cat > /tmp/test-supabase.js << 'EOF'
const { createClient } = require('@supabase/supabase-js')
const dotenv = require('dotenv')
dotenv.config({ path: '.env.local' })

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
)

async function test() {
  try {
    // Test 1: Check connection
    const { data: orgs, error } = await supabase.from('organizations').select('count')
    if (error) throw error

    console.log('✓ Connection successful!')
    console.log(`✓ Found ${orgs?.length || 0} organizations`)

    // Test 2: List tables
    const { data: tables } = await supabase.rpc('match_training_documents', {
      query_embedding: Array(1536).fill(0),
      match_org_id: '00000000-0000-0000-0000-000000000001',
      match_threshold: 0.7,
      match_count: 1
    })

    console.log('✓ pgvector extension working')
    process.exit(0)
  } catch (err) {
    console.error('✗ Connection failed:', err.message)
    process.exit(1)
  }
}

test()
EOF

cd /Users/macbook/mekong-cli/apps/sophia-factory
if node /tmp/test-supabase.js 2>/dev/null; then
    echo -e "${GREEN}✓ Supabase connection verified!${NC}"
else
    echo -e "${YELLOW}⚠ Connection test skipped (you can run 'npm run dev' to test)${NC}"
fi

rm /tmp/test-supabase.js

# Final summary
echo ""
echo -e "${BLUE}═══════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}✓ SETUP COMPLETE!${NC}"
echo -e "${BLUE}═══════════════════════════════════════════════════════${NC}"
echo ""
echo "Next steps:"
echo "  1. Run: npm run dev"
echo "  2. Open: http://localhost:3000"
echo "  3. Create your first organization and user"
echo ""
echo "Files created/modified:"
echo "  - .env.local (your credentials)"
echo "  - database/03-rls-policies.sql (security policies)"
echo ""
echo -e "${YELLOW}Important:${NC} Keep .env.local secure and never commit it to git!"
echo ""
