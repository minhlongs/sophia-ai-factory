/**
 * Test Supabase Connection
 * Run with: node scripts/test-supabase-connection.js
 */

const { createClient } = require('@supabase/supabase-js')
require('dotenv').config({ path: '.env.local' })

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

if (!supabaseUrl || !supabaseAnonKey) {
  console.error('❌ Missing Supabase credentials in .env.local')
  console.error('Run: bash scripts/setup-supabase.sh')
  process.exit(1)
}

const supabase = createClient(supabaseUrl, supabaseAnonKey)

async function testConnection() {
  console.log('🔌 Testing Supabase connection...')
  console.log(`   URL: ${supabaseUrl}`)

  try {
    // Test 1: Simple query to organizations table
    console.log('\n📋 Querying organizations table...')
    const { data: orgs, error: orgError } = await supabase
      .from('organizations')
      .select('id, name, slug')
      .limit(5)

    if (orgError) throw orgError

    if (orgs && orgs.length > 0) {
      console.log(`✅ Found ${orgs.length} organization(s):`)
      orgs.forEach(org => {
        console.log(`   - ${org.name} (${org.slug})`)
      })
    } else {
      console.log('⚠️  No organizations found (run seed data to add demo data)')
    }

    // Test 2: Check users table
    console.log('\n👤 Querying users table...')
    const { data: users, error: usersError } = await supabase
      .from('users')
      .select('id, email, role')
      .limit(5)

    if (usersError) throw usersError

    if (users && users.length > 0) {
      console.log(`✅ Found ${users.length} user(s):`)
      users.forEach(user => {
        console.log(`   - ${user.email} (${user.role})`)
      })
    } else {
      console.log('⚠️  No users found')
    }

    // Test 3: Check pgvector extension
    console.log('\n🧪 Testing pgvector extension...')
    const { data: vectorTest, error: vectorError } = await supabase.rpc(
      'match_training_documents',
      {
        query_embedding: Array(1536).fill(0),
        match_org_id: '00000000-0000-0000-0000-000000000001',
        match_threshold: 0.7,
        match_count: 1
      }
    )

    if (vectorError) {
      if (vectorError.message.includes('does not exist')) {
        console.log('⚠️  pgvector function not found - run schema.sql first')
      } else {
        throw vectorError
      }
    } else {
      console.log('✅ pgvector extension working correctly')
    }

    // Test 4: List all tables
    console.log('\n📊 Verifying all tables exist...')
    const { data: tables, error: tablesError } = await supabase
      .from('organizations')
      .select('*', { count: 'exact', head: true })

    if (tablesError) throw tablesError
    console.log('✅ organizations table: OK')

    await supabase.from('users').select('*', { count: 'exact', head: true })
    console.log('✅ users table: OK')

    await supabase.from('brand_voices').select('*', { count: 'exact', head: true })
    console.log('✅ brand_voices table: OK')

    await supabase.from('proposals').select('*', { count: 'exact', head: true })
    console.log('✅ proposals table: OK')

    await supabase.from('templates').select('*', { count: 'exact', head: true })
    console.log('✅ templates table: OK')

    await supabase.from('training_documents').select('*', { count: 'exact', head: true })
    console.log('✅ training_documents table: OK')

    console.log('\n' + '='.repeat(50))
    console.log('✅ ALL TESTS PASSED - Supabase is ready!')
    console.log('='.repeat(50))

  } catch (error) {
    console.error('\n❌ Connection test failed:')
    console.error(`   ${error.message}`)
    console.error('\n💡 Troubleshooting:')
    console.error('   1. Check your credentials in .env.local')
    console.error('   2. Make sure you ran schema.sql in Supabase SQL Editor')
    console.error('   3. Verify your Supabase project is active')
    process.exit(1)
  }
}

testConnection()
